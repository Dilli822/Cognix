
1. JS Variables and Scopes
2. Data types and String Concatenation with plus & template literal
3. Array and Loop - for, while, for in, for each, for of 
4. Object and try catch method
5. Localstorage, function and event listener IPO
6. JSON Format and Types of Json Format
7. For of loop and anonymonous function

----- The difference between loops are -----

1. FOR - When we want to control the loop and know the number of iterations

2. WHILE - we rely upon the condition that means loop terminates until the condition is meet it's just like having condition of dynamic input

3. FOR IN - we use this mostly for the object properties like bike have properties of color, price, mileage used in objects properties mostly with keys, donot use for array it is believed it will show unexpected behaviour

4. FOR OF - Iterate over a sequence of iterable like arrays, strings,

5. The forEach() method of Array instances executes a provided function once for each array element.

READ MORE ON:
https://developer.mozilla.org/en-US/docs/Web/JavaScript